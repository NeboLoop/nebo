#!/bin/bash
set -euo pipefail

# ─── CI Pipeline for Nebo VM Rootfs ──────────────────────────────────────────
#
# Intended for GitHub Actions, but works in any Linux CI environment.
#
# Usage:
#   ./scripts/ci.sh [aarch64|x86_64|both]
#
# Environment variables:
#   NEBO_GUEST_BIN_AARCH64 — path to pre-built aarch64 nebo-guest binary
#   NEBO_GUEST_BIN_X86_64  — path to pre-built x86_64 nebo-guest binary
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
ARCH="${1:-both}"

echo "══════════════════════════════════════════════════"
echo "  Nebo VM Rootfs CI Build"
echo "  Architecture: ${ARCH}"
echo "  Date: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "══════════════════════════════════════════════════"

# Install host dependencies
if command -v apt-get &>/dev/null; then
    echo "[ci] Installing build dependencies..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq \
        build-essential wget cpio unzip rsync bc perl python3 \
        file libncurses-dev
fi

# Copy pre-built guest daemon binaries if provided
if [ -n "${NEBO_GUEST_BIN_AARCH64:-}" ]; then
    echo "[ci] Using pre-built nebo-guest for aarch64: $NEBO_GUEST_BIN_AARCH64"
    mkdir -p "${PROJECT_DIR}/br2-external/board/nebo/rootfs_overlay/usr/local/bin"
    cp "$NEBO_GUEST_BIN_AARCH64" "${PROJECT_DIR}/br2-external/board/nebo/rootfs_overlay/usr/local/bin/nebo-guest"
    chmod 755 "${PROJECT_DIR}/br2-external/board/nebo/rootfs_overlay/usr/local/bin/nebo-guest"
fi

# Run the build
exec "${SCRIPT_DIR}/build.sh" "$ARCH"
