#!/bin/bash
set -euo pipefail

# ─── Update nebo-guest in an existing rootfs image ───────────────────────────
#
# Usage:
#   ./scripts/update-guest.sh <rootfs.cpio.gz> <nebo-guest-binary>
#
# This extracts the cpio archive, replaces the guest daemon, and repacks.
# Much faster than a full Buildroot rebuild.
#

if [ $# -ne 2 ]; then
    echo "Usage: $0 <rootfs.cpio.gz> <nebo-guest-binary>"
    echo ""
    echo "Example:"
    echo "  cargo build --target aarch64-unknown-linux-musl --release -p nebo-guest"
    echo "  $0 dist/nebo-vm-rootfs-aarch64.cpio.gz target/aarch64-unknown-linux-musl/release/nebo-guest"
    exit 1
fi

ROOTFS="$1"
GUEST_BIN="$2"

if [ ! -f "$ROOTFS" ]; then
    echo "Error: rootfs not found: $ROOTFS"
    exit 1
fi

if [ ! -f "$GUEST_BIN" ]; then
    echo "Error: nebo-guest binary not found: $GUEST_BIN"
    exit 1
fi

# Verify it's a static binary
if file "$GUEST_BIN" | grep -q "dynamically linked"; then
    echo "Error: nebo-guest must be statically linked (use --target *-unknown-linux-musl)"
    exit 1
fi

WORK_DIR=$(mktemp -d)
trap "rm -rf $WORK_DIR" EXIT

echo "[nebo-vm] Extracting rootfs..."
cd "$WORK_DIR"
gzip -d -c "$ROOTFS" | cpio -idm 2>/dev/null

echo "[nebo-vm] Replacing nebo-guest..."
cp "$GUEST_BIN" "$WORK_DIR/usr/local/bin/nebo-guest"
chmod 755 "$WORK_DIR/usr/local/bin/nebo-guest"

echo "[nebo-vm] Repacking rootfs..."
cd "$WORK_DIR"
find . | cpio -o -H newc 2>/dev/null | gzip > "${ROOTFS}.new"

mv "${ROOTFS}.new" "$ROOTFS"
sha256sum "$ROOTFS" > "${ROOTFS}.sha256"

SIZE=$(du -h "$ROOTFS" | cut -f1)
echo "[nebo-vm] Updated rootfs: $ROOTFS ($SIZE)"
echo "[nebo-vm] SHA256: $(cat ${ROOTFS}.sha256 | cut -d' ' -f1)"
