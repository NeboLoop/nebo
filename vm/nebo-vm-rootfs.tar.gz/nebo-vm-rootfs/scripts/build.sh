#!/bin/bash
set -euo pipefail

# ─── Nebo VM Rootfs Build Script ─────────────────────────────────────────────
#
# Usage:
#   ./scripts/build.sh              # Build for current host arch
#   ./scripts/build.sh aarch64      # Build for Apple Silicon
#   ./scripts/build.sh x86_64       # Build for Intel/AMD
#   ./scripts/build.sh both         # Build both architectures
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BUILDROOT_VERSION="2025.02.2"
BUILDROOT_DIR="${PROJECT_DIR}/buildroot"

ARCH="${1:-aarch64}"

# ─── Colors ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[nebo-vm]${NC} $*"; }
warn()  { echo -e "${YELLOW}[nebo-vm]${NC} $*"; }
error() { echo -e "${RED}[nebo-vm]${NC} $*" >&2; }

# ─── Check prerequisites ────────────────────────────────────────────────────
check_prereqs() {
    local missing=()
    for cmd in make gcc g++ wget cpio unzip rsync bc perl python3; do
        if ! command -v "$cmd" &>/dev/null; then
            missing+=("$cmd")
        fi
    done

    if [ ${#missing[@]} -gt 0 ]; then
        error "Missing build dependencies: ${missing[*]}"
        error "Install them with:"
        error "  Ubuntu/Debian: sudo apt-get install build-essential wget cpio unzip rsync bc perl python3 file"
        error "  Fedora:        sudo dnf install @development-tools wget cpio unzip rsync bc perl python3 file"
        error ""
        error "On macOS, use Docker instead:"
        error "  docker run --rm -v \$PWD:/nebo-vm-rootfs -w /nebo-vm-rootfs ubuntu:24.04 bash scripts/build.sh"
        exit 1
    fi
}

# ─── Download Buildroot ──────────────────────────────────────────────────────
download_buildroot() {
    if [ -d "${BUILDROOT_DIR}" ]; then
        info "Buildroot already present at ${BUILDROOT_DIR}"
        return
    fi

    info "Downloading Buildroot ${BUILDROOT_VERSION}..."
    wget -q "https://buildroot.org/downloads/buildroot-${BUILDROOT_VERSION}.tar.xz" \
        -O "/tmp/buildroot-${BUILDROOT_VERSION}.tar.xz"

    info "Extracting..."
    tar xf "/tmp/buildroot-${BUILDROOT_VERSION}.tar.xz" -C "${PROJECT_DIR}"
    mv "${PROJECT_DIR}/buildroot-${BUILDROOT_VERSION}" "${BUILDROOT_DIR}"
    rm "/tmp/buildroot-${BUILDROOT_VERSION}.tar.xz"

    info "Buildroot ${BUILDROOT_VERSION} ready"
}

# ─── Build for a specific architecture ───────────────────────────────────────
build_arch() {
    local arch="$1"
    local output_dir="${PROJECT_DIR}/output-${arch}"

    info "Building Nebo VM rootfs for ${arch}..."

    # Apply defconfig
    make -C "${BUILDROOT_DIR}" \
        BR2_EXTERNAL="${PROJECT_DIR}/br2-external" \
        O="${output_dir}" \
        nebo_vm_defconfig

    # Override architecture if building x86_64
    if [ "$arch" = "x86_64" ]; then
        # Patch the .config for x86_64
        sed -i 's/BR2_aarch64=y/# BR2_aarch64 is not set/' "${output_dir}/.config"
        echo "BR2_x86_64=y" >> "${output_dir}/.config"
        echo "BR2_x86_corei7=y" >> "${output_dir}/.config"

        # Re-run olddefconfig to resolve dependencies
        make -C "${output_dir}" olddefconfig
    fi

    # Build (use all available cores)
    local jobs=$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 4)
    info "Building with ${jobs} parallel jobs..."
    make -C "${output_dir}" -j"${jobs}"

    info "Build complete for ${arch}"
    info "Image: ${output_dir}/images/rootfs.cpio.gz"

    # Copy to a predictable location
    mkdir -p "${PROJECT_DIR}/dist"
    cp "${output_dir}/images/rootfs.cpio.gz" "${PROJECT_DIR}/dist/nebo-vm-rootfs-${arch}.cpio.gz"
    cp "${output_dir}/images/rootfs.cpio.gz.sha256" "${PROJECT_DIR}/dist/nebo-vm-rootfs-${arch}.cpio.gz.sha256" 2>/dev/null || true

    if [ -f "${output_dir}/images/nebo-vm-manifest.json" ]; then
        cp "${output_dir}/images/nebo-vm-manifest.json" "${PROJECT_DIR}/dist/nebo-vm-manifest-${arch}.json"
    fi

    info "Output: dist/nebo-vm-rootfs-${arch}.cpio.gz"
}

# ─── Main ────────────────────────────────────────────────────────────────────
main() {
    info "Nebo VM Rootfs Builder"
    info "====================="

    check_prereqs
    download_buildroot

    case "$ARCH" in
        both)
            build_arch "aarch64"
            build_arch "x86_64"
            info "Both architectures built successfully"
            ls -lh "${PROJECT_DIR}/dist/"
            ;;
        aarch64|x86_64)
            build_arch "$ARCH"
            ;;
        *)
            error "Unknown architecture: $ARCH"
            error "Usage: $0 [aarch64|x86_64|both]"
            exit 1
            ;;
    esac
}

main
