include $(sort $(wildcard $(BR2_EXTERNAL_NEBO_VM_PATH)/package/*/*.mk))
