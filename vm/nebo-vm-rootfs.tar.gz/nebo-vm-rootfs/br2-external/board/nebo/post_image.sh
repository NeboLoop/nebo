#!/bin/bash
#
# post_image.sh — Runs after filesystem images are created.
#
# $1 = path to the images directory (output/images/)
#

IMAGES_DIR="$1"
ROOTFS="${IMAGES_DIR}/rootfs.cpio.gz"

if [ ! -f "${ROOTFS}" ]; then
    echo "[nebo-vm] ERROR: rootfs.cpio.gz not found!"
    exit 1
fi

# Generate checksums
sha256sum "${ROOTFS}" > "${ROOTFS}.sha256"

# Report
SIZE=$(du -h "${ROOTFS}" | cut -f1)
echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Nebo VM rootfs built successfully"
echo "  Image: ${ROOTFS}"
echo "  Size:  ${SIZE}"
echo "  SHA256: $(cat ${ROOTFS}.sha256 | cut -d' ' -f1)"
echo "═══════════════════════════════════════════════════════"
echo ""

# Also create a version manifest
cat > "${IMAGES_DIR}/nebo-vm-manifest.json" << EOF
{
  "version": "0.1.0",
  "built_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "image": "rootfs.cpio.gz",
  "size_bytes": $(stat -f%z "${ROOTFS}" 2>/dev/null || stat -c%s "${ROOTFS}" 2>/dev/null),
  "sha256": "$(sha256sum ${ROOTFS} | cut -d' ' -f1)",
  "contents": {
    "kernel": "$(cat ${IMAGES_DIR}/../build/linux-*/.version 2>/dev/null || echo 'unknown')",
    "node": "$(grep NODEJS_VERSION ${IMAGES_DIR}/../build/nodejs-*/.stamp_built 2>/dev/null | head -1 || echo 'unknown')",
    "python": "$(grep PYTHON3_VERSION ${IMAGES_DIR}/../build/python3-*/.stamp_built 2>/dev/null | head -1 || echo 'unknown')",
    "musl": "musl"
  }
}
EOF
