#!/bin/bash
#
# post_build.sh — Runs after Buildroot builds all packages, before image creation.
#
# $1 = path to the target rootfs directory
#

TARGET_DIR="$1"

echo "[nebo-vm] Post-build: cleaning up target rootfs"

# ─── Remove unnecessary files to shrink image ─────────────────────────────────

# Remove documentation
rm -rf "${TARGET_DIR}/usr/share/doc"
rm -rf "${TARGET_DIR}/usr/share/man"
rm -rf "${TARGET_DIR}/usr/share/info"
rm -rf "${TARGET_DIR}/usr/share/locale"

# Remove Python test suites (these are huge)
find "${TARGET_DIR}/usr/lib/python3"* -name "test" -type d -exec rm -rf {} + 2>/dev/null
find "${TARGET_DIR}/usr/lib/python3"* -name "tests" -type d -exec rm -rf {} + 2>/dev/null
find "${TARGET_DIR}/usr/lib/python3"* -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null

# Remove Python .pyc files (they'll be regenerated on first use)
find "${TARGET_DIR}" -name "*.pyc" -delete 2>/dev/null

# Remove Node.js test directories
find "${TARGET_DIR}/usr/lib/node_modules" -name "test" -type d -exec rm -rf {} + 2>/dev/null
find "${TARGET_DIR}/usr/lib/node_modules" -name "tests" -type d -exec rm -rf {} + 2>/dev/null

# Remove static libraries (we don't need them at runtime)
find "${TARGET_DIR}/usr/lib" -name "*.a" -delete 2>/dev/null

# Remove header files (agents don't compile C against system headers)
# Keep them if we want npm native modules to work — commented out for now:
# rm -rf "${TARGET_DIR}/usr/include"

# ─── Security hardening ───────────────────────────────────────────────────────

# Remove SUID/SGID bits from all binaries
find "${TARGET_DIR}" -type f \( -perm -4000 -o -perm -2000 \) -exec chmod a-s {} \; 2>/dev/null

# Ensure sessions directory exists and is writable
mkdir -p "${TARGET_DIR}/sessions"
chmod 755 "${TARGET_DIR}/sessions"

# Ensure tmp is ready
mkdir -p "${TARGET_DIR}/tmp"
chmod 1777 "${TARGET_DIR}/tmp"

# ─── Verify guest daemon is present ──────────────────────────────────────────

if [ ! -f "${TARGET_DIR}/usr/local/bin/nebo-guest" ]; then
    echo "[nebo-vm] WARNING: nebo-guest binary not found in rootfs!"
    echo "[nebo-vm] Build the guest daemon first:"
    echo "[nebo-vm]   cargo build --target aarch64-unknown-linux-musl --release -p nebo-guest"
    # Don't fail the build — the overlay might add it separately
fi

echo "[nebo-vm] Post-build complete. Target rootfs: $(du -sh ${TARGET_DIR} | cut -f1)"
