################################################################################
#
# nebo-guest
#
################################################################################

# This package installs the pre-built nebo-guest binary into the rootfs.
# The binary is cross-compiled separately via:
#   cargo build --target $(ARCH)-unknown-linux-musl --release -p nebo-guest
#
# Set NEBO_GUEST_BIN to the path of the compiled binary before building:
#   make NEBO_GUEST_BIN=/path/to/nebo-guest

NEBO_GUEST_VERSION = 0.1.0
NEBO_GUEST_SITE_METHOD = local
NEBO_GUEST_SITE = $(NEBO_GUEST_BIN_DIR)
NEBO_GUEST_LICENSE = Apache-2.0

# The binary path is passed in from the build script
NEBO_GUEST_BIN_DIR ?= $(BR2_EXTERNAL_NEBO_VM_PATH)/../../target/$(BR2_ARCH)-unknown-linux-musl/release

define NEBO_GUEST_EXTRACT_CMDS
	# Nothing to extract — we copy the pre-built binary directly
endef

define NEBO_GUEST_BUILD_CMDS
	# Nothing to build — binary is pre-compiled
endef

define NEBO_GUEST_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(NEBO_GUEST_BIN_DIR)/nebo-guest \
		$(TARGET_DIR)/usr/local/bin/nebo-guest
endef

$(eval $(generic-package))
