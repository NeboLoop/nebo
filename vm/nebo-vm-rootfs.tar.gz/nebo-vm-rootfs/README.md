# Nebo VM Root Filesystem — Buildroot Configuration

Production-grade minimal Linux rootfs for Nebo's VM sandbox layer.

## What This Produces

A compressed root filesystem image (~50-80MB) containing:

- **Minimal Linux kernel** — configured for VM-only operation (no hardware drivers, no GPU, no USB)
- **musl libc** — smaller and simpler than glibc
- **BusyBox** — core utilities (ls, cat, cp, etc.)
- **Node.js 22 LTS** — JavaScript runtime
- **Python 3.12** — Python runtime with pip
- **Git** — version control
- **Rust toolchain artifacts** — for native module compilation
- **nebo-guest** — the Nebo guest daemon (Rust, statically linked)

## What This Does NOT Include

- systemd (uses BusyBox init — boots in <1 second)
- Desktop environment / X11 / Wayland
- Hardware drivers (no GPU, USB, audio, Bluetooth — it's a VM)
- Package manager (apk/apt) — everything is baked in at build time
- SSH server (communication is vsock only)
- Any network-facing services (no sshd, no httpd)

## Directory Structure

```
nebo-vm-rootfs/
├── README.md                          # This file
├── Makefile                           # Top-level build orchestration
├── configs/
│   └── nebo_vm_defconfig              # Buildroot defconfig for Nebo VM
├── br2-external/
│   ├── external.desc                  # BR2_EXTERNAL identity
│   ├── external.mk                    # Include custom package makefiles
│   ├── Config.in                      # Custom package menu entries
│   ├── configs/
│   │   └── nebo_vm_defconfig          # Symlink to ../configs/
│   ├── package/
│   │   └── nebo-guest/
│   │       ├── Config.in              # Kconfig entry for nebo-guest
│   │       ├── nebo-guest.mk          # Build recipe
│   │       └── nebo-guest.hash        # Integrity hash
│   └── board/
│       └── nebo/
│           ├── post_build.sh          # Runs after build, before image
│           ├── post_image.sh          # Runs after image creation
│           ├── rootfs_overlay/        # Files copied into rootfs as-is
│           │   ├── etc/
│           │   │   ├── inittab        # BusyBox init config
│           │   │   ├── init.d/
│           │   │   │   └── S99nebo    # Guest daemon startup script
│           │   │   └── profile        # Shell env defaults
│           │   └── usr/
│           │       └── local/
│           │           └── bin/       # nebo-guest goes here
│           └── linux.config           # Minimal kernel config
└── scripts/
    ├── build.sh                       # Full build from scratch
    ├── rebuild.sh                     # Incremental rebuild
    ├── update-guest.sh                # Rebuild just the guest daemon
    └── ci.sh                          # CI pipeline script
```

## Prerequisites

Buildroot builds its own cross-compilation toolchain. You need:

- A Linux host (or Docker — see below)
- ~8GB disk space for the build tree
- `make`, `gcc`, `g++` (host compiler for building the cross-compiler)
- `wget`, `cpio`, `unzip`, `rsync`, `bc`, `perl`, `python3`

On macOS, use the Docker path — Buildroot requires a Linux host.

## Quick Start

```bash
# Clone Buildroot (use LTS release)
git clone --depth 1 --branch 2025.02 https://gitlab.com/buildroot.org/buildroot.git

# Run the build
make -C buildroot \
  BR2_EXTERNAL=$PWD/br2-external \
  O=$PWD/output \
  nebo_vm_defconfig

make -C $PWD/output
```

The output image lands at `output/images/rootfs.cpio.gz` (~50-80MB).

## Docker Build (macOS / CI)

```bash
docker run --rm -it \
  -v $PWD:/nebo-vm-rootfs \
  -w /nebo-vm-rootfs \
  ubuntu:24.04 \
  bash -c "apt-get update && apt-get install -y build-essential wget cpio unzip rsync bc perl python3 file && ./scripts/build.sh"
```

## How It Integrates With Nebo

The `VmManager` in `crates/vm/` boots this rootfs image using the OS-native hypervisor:

- **macOS**: `Virtualization.framework` — loads the kernel + initramfs directly
- **Windows**: Hyper-V / HCS — boots from the compressed image
- **Linux**: KVM via `/dev/kvm`

On first launch, Nebo extracts the bundled rootfs to `~/.nebo/vm/`. Subsequent boots
use the cached image. Updates ship with Nebo releases.

## Updating the Guest Daemon

When `nebo-guest` changes, you don't need to rebuild the entire rootfs:

```bash
# Cross-compile the guest daemon
cargo build --target aarch64-unknown-linux-musl --release -p nebo-guest

# Inject it into the existing rootfs
./scripts/update-guest.sh output/images/rootfs.cpio.gz \
  target/aarch64-unknown-linux-musl/release/nebo-guest
```

## Build Targets

| Target | Image | Use Case |
|--------|-------|----------|
| `aarch64` | `rootfs.cpio.gz` | Apple Silicon Macs |
| `x86_64` | `rootfs.cpio.gz` | Intel Macs, Windows, Linux |

Both are built in CI. The Nebo installer bundles the correct one for the platform.

## Kernel Configuration Notes

The kernel config (`board/nebo/linux.config`) is stripped to the absolute minimum:

- **Yes**: virtio (block, net, console, vsock), cgroups v2, namespaces, seccomp, ext4, tmpfs, overlayfs, proc, sysfs, devtmpfs
- **No**: all hardware drivers, GPU, sound, USB, Bluetooth, WiFi, filesystems we don't use, debugging, tracing

This keeps the kernel under 5MB compressed and boot time under 1 second.
